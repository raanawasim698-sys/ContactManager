'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const session = require('express-session');

const db = require('./config/db');
const googleAuth = require('./services/googleAuth');
const smsService = require('./services/smsService');
const { attachUser } = require('./middleware/auth');

const authRoutes = require('./routes/auth');
const contactsRoutes = require('./routes/contacts');
const smsRoutes = require('./routes/sms');
const userRoutes = require('./routes/user');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

/* ------------------------------------------------------------------ *
 * Core middleware
 * ------------------------------------------------------------------ */

app.set('trust proxy', 1);
app.disable('x-powered-by');

// Credentialed CORS: an explicit origin list, never a wildcard, because the
// session cookie must travel with API requests.
const allowedOrigins = (process.env.CORS_ORIGIN || `http://localhost:${PORT}`)
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(
  cors({
    origin(origin, callback) {
      // Same-origin requests and tools like Postman send no Origin header.
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error(`Origin ${origin} is not allowed by CORS.`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

if (!process.env.SESSION_SECRET) {
  console.warn(
    '[startup] SESSION_SECRET is not set — using a temporary development secret. ' +
      'Set SESSION_SECRET in .env before deploying.'
  );
}

app.use(
  session({
    name: 'cm.sid',
    secret: process.env.SESSION_SECRET || 'development-only-secret-change-me',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: IS_PRODUCTION,
      maxAge: 7 * 24 * 60 * 60 * 1000
    }
  })
);

app.use(attachUser);

/* ------------------------------------------------------------------ *
 * Static frontend
 * ------------------------------------------------------------------ */

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

/* ------------------------------------------------------------------ *
 * Routes
 * ------------------------------------------------------------------ */

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    googleOAuthConfigured: googleAuth.isConfigured(),
    smsConfigured: smsService.isConfigured()
  });
});

app.use('/auth', authRoutes);
app.use('/api/contacts', contactsRoutes);
app.use('/api/sms', smsRoutes);
app.use('/api', userRoutes);

/* ------------------------------------------------------------------ *
 * 404 + centralised error handling
 * ------------------------------------------------------------------ */

app.use((req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) {
    return res.status(404).json({ success: false, message: 'Endpoint not found' });
  }
  next();
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  const status = err.status || err.statusCode || 500;

  // Full detail server-side, never in the response body.
  console.error(`[error] ${req.method} ${req.path} — ${err.message}`);
  if (!IS_PRODUCTION && status >= 500 && err.stack) console.error(err.stack);

  const message =
    status >= 500
      ? 'Something went wrong on the server. Check the server logs for details.'
      : err.message;

  if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) {
    return res.status(status).json({ success: false, message });
  }
  return res.status(status).send(message);
});

/* ------------------------------------------------------------------ *
 * Startup
 * ------------------------------------------------------------------ */

async function start() {
  try {
    const info = await db.initDatabase();
    console.log(`[startup] MySQL connected — ${info.host}:${info.port}/${info.database}`);
  } catch (err) {
    console.error('[startup] Database startup failed.');
    console.error(`          ${err.message}`);
    process.exit(1);
  }

  if (!googleAuth.isConfigured()) {
    console.warn(
      '[startup] Google OAuth is not configured. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET ' +
        'and GOOGLE_REDIRECT_URI in .env before signing in.'
    );
  }
  if (!smsService.isConfigured()) {
    console.warn('[startup] SMS provider is not configured. Everything except SMS still works.');
  }

  const server = app.listen(PORT, () => {
    console.log(`[startup] Contact Messenger running at http://localhost:${PORT}`);
  });

  const shutdown = async (signal) => {
    console.log(`\n[shutdown] ${signal} received — closing server.`);
    server.close(async () => {
      await db.closeDatabase().catch(() => {});
      process.exit(0);
    });
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

if (require.main === module) {
  start();
}

module.exports = app;
