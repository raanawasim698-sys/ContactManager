'use strict';

/**
 * Session-based authentication.
 *
 * The browser only ever holds a signed session cookie. OAuth tokens stay in
 * MySQL and are looked up server-side by `req.session.userId`.
 */

function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    req.userId = req.session.userId;
    return next();
  }

  return res.status(401).json({
    success: false,
    message: 'Authentication required'
  });
}

/** Attaches req.userId when present but never blocks the request. */
function attachUser(req, _res, next) {
  if (req.session && req.session.userId) {
    req.userId = req.session.userId;
  }
  next();
}

module.exports = { requireAuth, attachUser };
