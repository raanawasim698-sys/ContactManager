'use strict';

/**
 * MySQL connection layer.
 *
 * - One shared connection pool for the whole process (never a new connection per request).
 * - initDatabase() creates the database if missing, then applies database/schema.sql.
 * - All queries elsewhere in the app use parameterised placeholders (`?`) only.
 */

const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_PORT = Number(process.env.DB_PORT || 3306);
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'contact_messenger';

let pool = null;

/**
 * Returns the shared pool. Throws if initDatabase() has not run yet.
 */
function getPool() {
  if (!pool) {
    throw new Error('Database pool is not initialised. Call initDatabase() during server startup.');
  }
  return pool;
}

/**
 * Convenience wrapper so route files can do `db.query(sql, params)`.
 */
async function query(sql, params = []) {
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

/**
 * Runs `fn(connection)` inside a transaction, committing on success and
 * rolling back on any thrown error.
 */
async function withTransaction(fn) {
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const result = await fn(connection);
    await connection.commit();
    return result;
  } catch (err) {
    try {
      await connection.rollback();
    } catch (_) {
      /* rollback failure is not more useful than the original error */
    }
    throw err;
  } finally {
    connection.release();
  }
}

/**
 * Splits schema.sql into individual statements. The schema deliberately
 * contains no stored procedures or triggers, so a simple `;` split is safe.
 */
function readSchemaStatements() {
  const schemaPath = path.join(__dirname, '..', 'database', 'schema.sql');
  const raw = fs.readFileSync(schemaPath, 'utf8');

  return raw
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n')
    .split(';')
    .map((statement) => statement.trim())
    // CREATE DATABASE / USE are handled by the connection itself.
    .filter((statement) => statement.length > 0)
    .filter((statement) => !/^CREATE\s+DATABASE/i.test(statement))
    .filter((statement) => !/^USE\s+/i.test(statement));
}

/**
 * Creates the database if it does not exist, builds the pool, applies the
 * schema and verifies connectivity. Throws a readable error on failure so the
 * server can refuse to start.
 */
async function initDatabase() {
  // Step 1: connect without a database selected so we can CREATE DATABASE.
  let bootstrap;
  try {
    bootstrap = await mysql.createConnection({
      host: DB_HOST,
      port: DB_PORT,
      user: DB_USER,
      password: DB_PASSWORD,
      multipleStatements: false
    });
  } catch (err) {
    throw new Error(
      `Cannot reach MySQL at ${DB_HOST}:${DB_PORT} as user "${DB_USER}". ` +
        `Check that MySQL is running and that DB_HOST/DB_PORT/DB_USER/DB_PASSWORD in .env are correct. ` +
        `(${err.code || err.message})`
    );
  }

  try {
    await bootstrap.query(
      `CREATE DATABASE IF NOT EXISTS \`${DB_NAME.replace(/`/g, '')}\` ` +
        `CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
  } finally {
    await bootstrap.end();
  }

  // Step 2: build the shared pool against the real database.
  pool = mysql.createPool({
    host: DB_HOST,
    port: DB_PORT,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4_unicode_ci',
    enableKeepAlive: true
  });

  // Step 3: apply the schema (idempotent — every statement is IF NOT EXISTS).
  const statements = readSchemaStatements();
  const connection = await pool.getConnection();
  try {
    for (const statement of statements) {
      await connection.query(statement);
    }
    await connection.query('SELECT 1');
  } catch (err) {
    throw new Error(`Failed to apply database schema: ${err.sqlMessage || err.message}`);
  } finally {
    connection.release();
  }

  return { host: DB_HOST, port: DB_PORT, database: DB_NAME };
}

async function closeDatabase() {
  if (pool) {
    await pool.end();
    pool = null;
  }
}

module.exports = {
  getPool,
  query,
  withTransaction,
  initDatabase,
  closeDatabase,
  DB_NAME
};
