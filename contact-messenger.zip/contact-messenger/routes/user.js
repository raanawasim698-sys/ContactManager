'use strict';

const express = require('express');
const db = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const smsService = require('../services/smsService');

const router = express.Router();

/**
 * GET /api/me
 * Returns the signed-in user. Never returns OAuth tokens or any secret.
 */
router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const rows = await db.query(
      'SELECT id, name, email, picture FROM users WHERE id = ? LIMIT 1',
      [req.userId]
    );

    if (rows.length === 0) {
      return req.session.destroy(() =>
        res.status(401).json({ success: false, message: 'Authentication required' })
      );
    }

    const [countRow] = await db.query(
      'SELECT COUNT(*) AS total FROM contacts WHERE user_id = ?',
      [req.userId]
    );

    return res.json({
      id: rows[0].id,
      name: rows[0].name,
      email: rows[0].email,
      picture: rows[0].picture,
      contactCount: Number(countRow.total),
      smsConfigured: smsService.isConfigured()
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
