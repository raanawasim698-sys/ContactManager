'use strict';

const crypto = require('crypto');
const express = require('express');
const db = require('../config/db');
const googleAuth = require('../services/googleAuth');

const router = express.Router();

/**
 * GET /auth/google
 * Sends the browser to Google's consent screen.
 */
router.get('/google', (req, res, next) => {
  try {
    if (!googleAuth.isConfigured()) {
      return res.redirect('/?error=' + encodeURIComponent('Google sign-in is not configured on the server.'));
    }

    // CSRF protection for the OAuth round-trip.
    const state = crypto.randomBytes(24).toString('hex');
    req.session.oauthState = state;

    // Force the consent screen only when this browser has not completed a
    // successful connection before — that is when we need the refresh token.
    const forceConsent = !req.session.hasConnectedGoogle;

    const url = googleAuth.getAuthUrl({ state, forceConsent });

    req.session.save((err) => {
      if (err) return next(err);
      res.redirect(url);
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /auth/callback
 * Google redirects here with ?code=... — this must match GOOGLE_REDIRECT_URI
 * and the Authorized redirect URI in Google Cloud Console exactly.
 */
router.get('/callback', async (req, res, next) => {
  const fail = (message) => res.redirect('/?error=' + encodeURIComponent(message));

  try {
    if (req.query.error) {
      return fail(
        req.query.error === 'access_denied'
          ? 'Google access was declined. Contact syncing needs read access to your contacts.'
          : 'Google sign-in failed. Please try again.'
      );
    }

    const code = req.query.code;
    if (!code || typeof code !== 'string') {
      return fail('Google did not return an authorization code. Please try again.');
    }

    if (!req.query.state || req.query.state !== req.session.oauthState) {
      return fail('Sign-in request could not be verified. Please start again.');
    }
    delete req.session.oauthState;

    // 1. Exchange the code for tokens.
    const { client, tokens } = await googleAuth.exchangeCodeForTokens(code);

    // 2. Identify the Google account.
    const profile = await googleAuth.fetchGoogleProfile(client);
    if (!profile.googleId) {
      return fail('Could not read your Google profile. Please try again.');
    }

    // 3. Create or update the local user, preserving an existing refresh token
    //    when Google does not issue a new one.
    const existing = await db.query(
      'SELECT id, refresh_token FROM users WHERE google_id = ? LIMIT 1',
      [profile.googleId]
    );

    let userId;
    if (existing.length > 0) {
      userId = existing[0].id;
      const refreshToken = tokens.refresh_token || existing[0].refresh_token || null;

      await db.query(
        `UPDATE users
            SET name = ?, email = ?, picture = ?,
                access_token = ?, refresh_token = ?, token_expiry = ?
          WHERE id = ?`,
        [
          profile.name,
          profile.email,
          profile.picture,
          tokens.access_token || null,
          refreshToken,
          tokens.expiry_date || null,
          userId
        ]
      );
    } else {
      const result = await db.getPool().execute(
        `INSERT INTO users (google_id, name, email, picture, access_token, refresh_token, token_expiry)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          profile.googleId,
          profile.name,
          profile.email,
          profile.picture,
          tokens.access_token || null,
          tokens.refresh_token || null,
          tokens.expiry_date || null
        ]
      );
      userId = result[0].insertId;
    }

    // 4. Store only the local user id in the session. No tokens go to the browser.
    req.session.userId = userId;
    req.session.hasConnectedGoogle = true;

    console.log('[auth] OAuth successful — Google user authenticated. User ID:', userId);

    req.session.save((err) => {
      if (err) return next(err);
      res.redirect('/dashboard.html');
    });
  } catch (err) {
    if (googleAuth.isInvalidGrant(err)) {
      return fail('That Google sign-in link has already been used or expired. Please try again.');
    }
    console.error('[auth] OAuth callback failed:', err.message);
    return fail('Google sign-in failed. Please try again.');
  }
});

/** Shared logout handler. */
function logout(req, res) {
  const wantsJson =
    req.method === 'POST' ||
    (req.get('accept') || '').includes('application/json') ||
    req.xhr;

  req.session.destroy((err) => {
    res.clearCookie('cm.sid');

    if (err) {
      console.error('[auth] Failed to destroy session:', err.message);
      if (wantsJson) {
        return res.status(500).json({ success: false, message: 'Could not sign you out. Please try again.' });
      }
      return res.redirect('/');
    }

    if (wantsJson) {
      return res.json({ success: true, message: 'Signed out' });
    }
    return res.redirect('/');
  });
}

router.get('/logout', logout);
router.post('/logout', logout);

module.exports = router;
