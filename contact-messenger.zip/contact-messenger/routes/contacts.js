'use strict';

const express = require('express');
const db = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const googleAuth = require('../services/googleAuth');
const { fetchAllGoogleContacts } = require('../services/googleContacts');
const contactStore = require('../services/contactStore');

const router = express.Router();

/**
 * GET /api/contacts
 * GET /api/contacts?search=ali
 *
 * PHASE 2 CONTRACT — do not change this shape:
 * [ { "id": 1, "name": "Ali Khan", "email": "ali@gmail.com", "phone": "+923001234567" } ]
 *
 * A bare array, exactly four fields per contact, `[]` when there are none.
 */
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';

    let rows;
    if (search.length > 0) {
      // Parameterised — user input is never concatenated into SQL.
      const like = `%${search.replace(/[%_\\]/g, (ch) => `\\${ch}`)}%`;
      rows = await db.query(
        `SELECT id, name, email, phone
           FROM contacts
          WHERE user_id = ?
            AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)
          ORDER BY name ASC, id ASC`,
        [req.userId, like, like, like]
      );
    } else {
      rows = await db.query(
        `SELECT id, name, email, phone
           FROM contacts
          WHERE user_id = ?
          ORDER BY name ASC, id ASC`,
        [req.userId]
      );
    }

    return res.json(
      rows.map((row) => ({
        id: row.id,
        name: row.name || '',
        email: row.email || null,
        phone: row.phone || null
      }))
    );
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/contacts/sync
 * Pulls every page of the user's Google contacts and upserts them into MySQL.
 */
router.post('/sync', requireAuth, async (req, res, next) => {
  const reauth = (message) =>
    req.session.destroy(() =>
      res.status(401).json({ success: false, message, code: 'REAUTH_REQUIRED' })
    );

  try {
    // 1. Authenticated Google client (refreshes the access token when needed).
    let authClient;
    try {
      authClient = await googleAuth.getAuthenticatedClientForUser(req.userId);
    } catch (err) {
      if (err instanceof googleAuth.ReauthRequiredError) return reauth(err.message);
      throw err;
    }

    // 2. Fetch every page from the People API.
    let fetched;
    try {
      fetched = await fetchAllGoogleContacts(authClient);
    } catch (err) {
      if (googleAuth.isInvalidGrant(err)) {
        await googleAuth.clearStoredTokens(req.userId);
        return reauth('Your Google connection was revoked. Please sign in with Google again.');
      }

      const status = (err.response && err.response.status) || err.code;
      if (status === 429 || status === 403) {
        return res.status(429).json({
          success: false,
          message: 'Google is rate-limiting this account. Wait a minute and sync again.'
        });
      }
      throw err;
    }

    // 3. Store, deduplicating against what is already saved.
    const stats = await contactStore.upsertContacts(req.userId, fetched.contacts);

    await contactStore.recordSyncRun(req.userId, {
      pages: fetched.pages,
      total: stats.total,
      inserted: stats.inserted,
      updated: stats.updated,
      skipped: stats.skipped
    });

    console.log(
      `[contacts] Sync complete for user ${req.userId} — inserted ${stats.inserted}, ` +
        `updated ${stats.updated}, unchanged ${stats.unchanged}`
    );

    return res.json({
      success: true,
      message: 'Contacts synchronized successfully',
      totalFetched: stats.total,
      inserted: stats.inserted,
      updated: stats.updated,
      unchanged: stats.unchanged,
      skipped: stats.skipped,
      pagesFetched: fetched.pages
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
