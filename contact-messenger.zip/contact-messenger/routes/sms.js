'use strict';

const express = require('express');
const db = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const smsService = require('../services/smsService');

const router = express.Router();

/** Blocks every SMS route with a clear message when Twilio is not set up. */
function requireSmsProvider(_req, res, next) {
  if (!smsService.isConfigured()) {
    return res.status(503).json({
      success: false,
      message: 'SMS provider is not configured.'
    });
  }
  next();
}

/**
 * GET /api/sms/status
 * Lets the dashboard show the right state without exposing any credential.
 */
router.get('/status', requireAuth, (_req, res) => {
  res.json({ success: true, configured: smsService.isConfigured() });
});

/**
 * POST /api/sms/send
 * Body: { "contactId": 1, "message": "Hello" }
 */
router.post('/send', requireAuth, requireSmsProvider, async (req, res, next) => {
  try {
    const contactId = Number(req.body && req.body.contactId);
    const message = req.body && req.body.message;

    if (!Number.isInteger(contactId) || contactId <= 0) {
      return res.status(400).json({ success: false, message: 'A valid contactId is required.' });
    }
    if (typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ success: false, message: 'Message cannot be empty.' });
    }

    // Ownership check — a user can only message their own contacts.
    const rows = await db.query(
      'SELECT id, name, phone FROM contacts WHERE id = ? AND user_id = ? LIMIT 1',
      [contactId, req.userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Contact not found.' });
    }

    const contact = rows[0];
    if (!contact.phone || !smsService.isSendablePhone(contact.phone)) {
      return res.status(400).json({
        success: false,
        message: `${contact.name || 'This contact'} has no usable phone number.`
      });
    }

    const result = await smsService.sendSms(contact.phone, message);

    console.log(`[sms] Message queued for contact ${contact.id} (user ${req.userId})`);

    return res.json({
      success: true,
      message: 'SMS sent successfully',
      contactId: contact.id,
      status: result.status
    });
  } catch (err) {
    if (err.status && err.status < 500) {
      return res.status(err.status).json({ success: false, message: err.message });
    }
    if (err.code === 'SMS_PROVIDER_ERROR') {
      return res.status(502).json({ success: false, message: err.message });
    }
    next(err);
  }
});

/**
 * POST /api/sms/send-all
 * Body: { "message": "Hello everyone." }
 * Only contacts with a usable phone number are contacted.
 */
router.post('/send-all', requireAuth, requireSmsProvider, async (req, res, next) => {
  try {
    const message = req.body && req.body.message;
    if (typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ success: false, message: 'Message cannot be empty.' });
    }

    const rows = await db.query(
      `SELECT id, name, phone
         FROM contacts
        WHERE user_id = ?
          AND phone IS NOT NULL
          AND phone <> ''`,
      [req.userId]
    );

    const recipients = rows.filter((row) => smsService.isSendablePhone(row.phone));

    if (recipients.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No contacts have a usable phone number.',
        total: 0,
        sent: 0,
        failed: 0
      });
    }

    const results = await smsService.sendBulkSms(recipients, message);

    console.log(
      `[sms] Bulk send finished for user ${req.userId} — ${results.sent} sent, ${results.failed} failed`
    );

    return res.json({
      success: true,
      total: results.total,
      sent: results.sent,
      failed: results.failed,
      failures: results.failures
    });
  } catch (err) {
    if (err.status && err.status < 500) {
      return res.status(err.status).json({ success: false, message: err.message });
    }
    next(err);
  }
});

module.exports = router;
