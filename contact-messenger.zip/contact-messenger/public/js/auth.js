/* Login page behaviour.
   No credentials, tokens or secrets are ever handled here — the browser only
   follows a redirect to /auth/google. */

(function ($) {
  'use strict';

  $(function () {
    // Surface any message passed back by the OAuth callback.
    var params = new URLSearchParams(window.location.search);
    var error = params.get('error');

    if (error) {
      $('#alert').text(error).removeClass('hidden');
      // Keep the address bar clean after reading the message.
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    // If a session already exists, go straight to the dashboard.
    $.ajax({ url: '/api/me', method: 'GET', dataType: 'json' })
      .done(function () {
        window.location.replace('/dashboard.html');
      })
      .fail(function () {
        /* Not signed in — stay on this page. */
      });

    // Small affordance so the button reads as "working" during the redirect.
    $('#google-btn').on('click', function () {
      var $btn = $(this);
      $btn.addClass('opacity-70 pointer-events-none');
      setTimeout(function () {
        $btn.removeClass('opacity-70 pointer-events-none');
      }, 6000);
    });
  });
})(jQuery);
