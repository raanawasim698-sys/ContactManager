/* Dashboard behaviour.
   Every contact shown here comes from GET /api/contacts — nothing is hard-coded.
   No credential, token or provider key is ever handled in the browser. */

(function ($) {
  'use strict';

  var state = {
    contacts: [],      // full list from the API
    filtered: [],      // current search result
    search: '',
    smsConfigured: false,
    activeContactId: null,
    syncing: false,
    sending: false
  };

  /* ------------------------------------------------------------------ *
   * Helpers
   * ------------------------------------------------------------------ */

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function plural(count, singular, pluralForm) {
    return count === 1 ? singular : pluralForm;
  }

  function toast(message, kind) {
    var palette = {
      success: 'border-teal bg-teal-light text-ink',
      error: 'border-danger/40 bg-danger/10 text-ink',
      info: 'border-rule bg-card text-ink'
    };

    var $toast = $('<div class="toast rounded-lg border px-4 py-3 text-sm shadow-lg ' +
      (palette[kind] || palette.info) + '"></div>').text(message);

    $('#toasts').append($toast);

    setTimeout(function () {
      $toast.addClass('leaving');
      setTimeout(function () { $toast.remove(); }, 200);
    }, kind === 'error' ? 6000 : 3800);
  }

  /** Reads the server's message out of a jQuery error, with a readable fallback. */
  function errorMessage(xhr, fallback) {
    if (xhr && xhr.responseJSON && xhr.responseJSON.message) return xhr.responseJSON.message;
    if (xhr && xhr.status === 0) return 'Cannot reach the server. Check that it is still running.';
    if (xhr && xhr.status === 429) return 'Too many requests right now. Try again in a minute.';
    return fallback;
  }

  function redirectToLogin(message) {
    var query = message ? '?error=' + encodeURIComponent(message) : '';
    window.location.replace('/' + query);
  }

  function handleAuthFailure(xhr) {
    if (!xhr || xhr.status !== 401) return false;
    redirectToLogin(errorMessage(xhr, 'Your session expired. Please sign in again.'));
    return true;
  }

  /* ------------------------------------------------------------------ *
   * Current user
   * ------------------------------------------------------------------ */

  function loadUser() {
    return $.ajax({ url: '/api/me', method: 'GET', dataType: 'json' })
      .done(function (user) {
        $('#user-name').text(user.name || 'Signed in');
        $('#user-email').text(user.email || '');

        if (user.picture) {
          $('#user-picture').attr('src', user.picture).attr('alt', user.name || '').removeClass('hidden');
        }

        state.smsConfigured = Boolean(user.smsConfigured);
        applySmsAvailability();
      })
      .fail(function (xhr) {
        if (!handleAuthFailure(xhr)) {
          toast(errorMessage(xhr, 'Could not load your account details.'), 'error');
        }
      });
  }

  function applySmsAvailability() {
    if (state.smsConfigured) {
      $('#sms-warning').addClass('hidden');
      $('#send-all-btn').prop('disabled', false).removeAttr('title');
    } else {
      $('#sms-warning').removeClass('hidden');
      $('#send-all-btn').prop('disabled', true).attr('title', 'SMS provider is not configured.');
    }
    $('.js-sms-btn').prop('disabled', !state.smsConfigured);
  }

  /* ------------------------------------------------------------------ *
   * Contacts
   * ------------------------------------------------------------------ */

  function loadContacts(options) {
    var silent = options && options.silent;

    if (!silent) {
      $('#loading-state').removeClass('hidden');
      $('#contact-list, #empty-state, #no-results').addClass('hidden');
    }

    return $.ajax({ url: '/api/contacts', method: 'GET', dataType: 'json' })
      .done(function (contacts) {
        state.contacts = Array.isArray(contacts) ? contacts : [];
        applySearch();
      })
      .fail(function (xhr) {
        if (handleAuthFailure(xhr)) return;
        $('#loading-state').addClass('hidden');
        toast(errorMessage(xhr, 'Could not load contacts.'), 'error');
      });
  }

  function matchesSearch(contact, term) {
    var name = (contact.name || '').toLowerCase();
    var email = (contact.email || '').toLowerCase();
    var phone = (contact.phone || '').toLowerCase();

    if (name.indexOf(term) !== -1) return true;
    if (email.indexOf(term) !== -1) return true;
    if (phone.indexOf(term) !== -1) return true;

    // Digits-only comparison so "0300 123" also finds "+923001234567".
    var termDigits = term.replace(/\D/g, '').replace(/^0+/, '');
    if (termDigits.length > 0) {
      var phoneDigits = phone.replace(/\D/g, '');
      if (phoneDigits.indexOf(termDigits) !== -1) return true;
    }

    return false;
  }

  function applySearch() {
    var term = state.search.trim().toLowerCase();

    state.filtered = term.length === 0
      ? state.contacts.slice()
      : state.contacts.filter(function (contact) { return matchesSearch(contact, term); });

    render();
  }

  function contactRowHtml(contact) {
    var name = escapeHtml(contact.name || 'Unnamed contact');
    var hasEmail = Boolean(contact.email);
    var hasPhone = Boolean(contact.phone);

    var email = hasEmail
      ? '<a href="mailto:' + escapeHtml(contact.email) + '" class="truncate text-sm text-teal-dark hover:underline">' + escapeHtml(contact.email) + '</a>'
      : '<span class="text-sm text-slate2/70">No email</span>';

    var phone = hasPhone
      ? '<span class="num text-sm">' + escapeHtml(contact.phone) + '</span>'
      : '<span class="text-sm text-slate2/70">No phone number</span>';

    var button = hasPhone
      ? '<button type="button" class="js-sms-btn w-[104px] rounded-md border border-teal px-3 py-1.5 text-xs font-medium text-teal-dark transition-colors hover:bg-teal hover:text-card disabled:cursor-not-allowed disabled:opacity-50" data-id="' + contact.id + '">Send SMS</button>'
      : '<span class="inline-block w-[104px] text-center text-xs text-slate2/70">No number</span>';

    return (
      '<li class="contact-row px-5 py-3.5">' +
        '<div class="sm:grid sm:grid-cols-[minmax(0,1.1fr)_minmax(0,1.2fr)_minmax(0,0.9fr)_auto] sm:items-center sm:gap-4">' +
          '<p class="truncate text-sm font-medium">' + name + '</p>' +
          '<div class="mt-1 flex min-w-0 sm:mt-0">' + email + '</div>' +
          '<div class="mt-0.5 sm:mt-0">' + phone + '</div>' +
          '<div class="mt-2.5 sm:mt-0 sm:text-right">' + button + '</div>' +
        '</div>' +
      '</li>'
    );
  }

  function render() {
    var total = state.contacts.length;
    var shown = state.filtered.length;
    var withPhone = state.contacts.filter(function (c) { return Boolean(c.phone); }).length;

    $('#loading-state').addClass('hidden');

    // Count line
    if (total === 0) {
      $('#contact-count').text('No contacts stored yet.');
    } else if (state.search.trim().length > 0) {
      $('#contact-count').text(
        shown + ' of ' + total + ' ' + plural(total, 'contact', 'contacts') + ' match'
      );
    } else {
      $('#contact-count').text(
        total + ' ' + plural(total, 'contact', 'contacts') + ' · ' + withPhone + ' with a phone number'
      );
    }

    // Empty / no-result / list
    if (total === 0) {
      $('#contact-list, #no-results').addClass('hidden');
      $('#empty-state').removeClass('hidden');
      return;
    }

    $('#empty-state').addClass('hidden');

    if (shown === 0) {
      $('#contact-list').addClass('hidden');
      $('#no-results-term').text('"' + state.search.trim() + '"');
      $('#no-results').removeClass('hidden');
      return;
    }

    $('#no-results').addClass('hidden');

    var html = state.filtered.map(contactRowHtml).join('');
    $('#contact-rows').html(html);

    var $list = $('#contact-list');
    var wasHidden = $list.hasClass('hidden');
    $list.removeClass('hidden');
    if (wasHidden) {
      $list.addClass('list-enter');
      setTimeout(function () { $list.removeClass('list-enter'); }, 320);
    }

    applySmsAvailability();
  }

  /* ------------------------------------------------------------------ *
   * Sync
   * ------------------------------------------------------------------ */

  function syncContacts() {
    if (state.syncing) return;
    state.syncing = true;

    var $btn = $('#sync-btn');
    $btn.prop('disabled', true);
    $('#sync-btn-label').html('Syncing<span class="spinner ml-2"></span>');

    $.ajax({
      url: '/api/contacts/sync',
      method: 'POST',
      contentType: 'application/json',
      dataType: 'json'
    })
      .done(function (result) {
        toast(
          'Contacts synchronized successfully. ' +
            result.inserted + ' added, ' + result.updated + ' updated, ' +
            result.totalFetched + ' fetched across ' + result.pagesFetched +
            ' ' + plural(result.pagesFetched, 'page', 'pages') + '.',
          'success'
        );
        loadContacts({ silent: true });
      })
      .fail(function (xhr) {
        if (handleAuthFailure(xhr)) return;
        toast(errorMessage(xhr, 'Sync failed. Check the server logs for details.'), 'error');
      })
      .always(function () {
        state.syncing = false;
        $btn.prop('disabled', false);
        $('#sync-btn-label').text('Sync contacts');
      });
  }

  /* ------------------------------------------------------------------ *
   * Modals
   * ------------------------------------------------------------------ */

  function openModal(id) {
    $('#' + id).removeClass('hidden');
    $('body').addClass('modal-open');
    setTimeout(function () { $('#' + id).find('textarea').trigger('focus'); }, 60);
  }

  function closeModal(id) {
    $('#' + id).addClass('hidden');
    $('body').removeClass('modal-open');
  }

  function openSmsModal(contactId) {
    var contact = state.contacts.filter(function (c) { return c.id === contactId; })[0];
    if (!contact) return;

    if (!contact.phone) {
      toast('That contact has no phone number.', 'error');
      return;
    }

    state.activeContactId = contact.id;
    $('#sms-contact-name').text(contact.name || 'Unnamed contact');
    $('#sms-contact-phone').text(contact.phone);
    $('#sms-message').val('');
    $('#sms-count').text('0');
    $('#sms-error').text('');
    $('#sms-send-label').text('Send SMS');
    $('#sms-send-btn').prop('disabled', false);

    openModal('sms-modal');
  }

  function sendSms() {
    if (state.sending) return;

    var message = $('#sms-message').val().trim();
    if (message.length === 0) {
      $('#sms-error').text('Message cannot be empty.');
      return;
    }
    $('#sms-error').text('');

    state.sending = true;
    $('#sms-send-btn').prop('disabled', true);
    $('#sms-send-label').html('Sending<span class="spinner ml-2"></span>');

    $.ajax({
      url: '/api/sms/send',
      method: 'POST',
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify({ contactId: state.activeContactId, message: message })
    })
      .done(function () {
        closeModal('sms-modal');
        toast('SMS sent successfully.', 'success');
      })
      .fail(function (xhr) {
        if (handleAuthFailure(xhr)) return;
        var msg = errorMessage(xhr, 'SMS failed. Please try again.');
        $('#sms-error').text(msg);
        toast(msg, 'error');
      })
      .always(function () {
        state.sending = false;
        $('#sms-send-btn').prop('disabled', false);
        $('#sms-send-label').text('Send SMS');
      });
  }

  function openBulkModal() {
    var withPhone = state.contacts.filter(function (c) { return Boolean(c.phone); }).length;

    if (withPhone === 0) {
      toast('None of your contacts have a phone number yet.', 'error');
      return;
    }

    $('#bulk-recipient-count').text(
      withPhone + ' ' + plural(withPhone, 'contact', 'contacts') + ' will receive this message.'
    );
    $('#bulk-message').val('');
    $('#bulk-count').text('0');
    $('#bulk-error').text('');
    $('#bulk-result').addClass('hidden').empty();
    $('#bulk-send-label').text('Send to all');
    $('#bulk-send-btn').prop('disabled', false);

    openModal('bulk-modal');
  }

  function sendBulkSms() {
    if (state.sending) return;

    var message = $('#bulk-message').val().trim();
    if (message.length === 0) {
      $('#bulk-error').text('Message cannot be empty.');
      return;
    }
    $('#bulk-error').text('');

    state.sending = true;
    $('#bulk-send-btn').prop('disabled', true);
    $('#bulk-send-label').html('Sending<span class="spinner ml-2"></span>');

    $.ajax({
      url: '/api/sms/send-all',
      method: 'POST',
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify({ message: message })
    })
      .done(function (result) {
        var summary = result.sent + ' of ' + result.total + ' sent';
        if (result.failed > 0) summary += ', ' + result.failed + ' failed';

        var $box = $('#bulk-result').removeClass('hidden').text(summary + '.');

        if (result.failures && result.failures.length > 0) {
          var $list = $('<ul class="mt-2 space-y-1 text-xs text-slate2"></ul>');
          result.failures.forEach(function (failure) {
            $list.append($('<li></li>').text((failure.name || 'Contact') + ' — ' + failure.reason));
          });
          $box.append($list);
        }

        toast(summary + '.', result.failed > 0 ? 'info' : 'success');
      })
      .fail(function (xhr) {
        if (handleAuthFailure(xhr)) return;
        var msg = errorMessage(xhr, 'Bulk send failed. Please try again.');
        $('#bulk-error').text(msg);
        toast(msg, 'error');
      })
      .always(function () {
        state.sending = false;
        $('#bulk-send-btn').prop('disabled', false);
        $('#bulk-send-label').text('Send to all');
      });
  }

  /* ------------------------------------------------------------------ *
   * Wiring
   * ------------------------------------------------------------------ */

  $(function () {
    loadUser().always(function () { loadContacts(); });

    // Search — instant, client-side, no reload.
    $('#search-input').on('input', function () {
      state.search = $(this).val();
      $('#clear-search').toggleClass('hidden', state.search.length === 0);
      applySearch();
    });

    $(document).on('click', '#clear-search, [data-action="clear-search"]', function () {
      state.search = '';
      $('#search-input').val('').trigger('focus');
      $('#clear-search').addClass('hidden');
      applySearch();
    });

    // Sync
    $(document).on('click', '#sync-btn, [data-action="sync"]', syncContacts);

    // Per-contact SMS (delegated — rows are re-rendered on every search).
    $(document).on('click', '.js-sms-btn', function () {
      openSmsModal(Number($(this).data('id')));
    });

    $('#sms-send-btn').on('click', sendSms);
    $('#sms-message').on('input', function () {
      $('#sms-count').text($(this).val().length);
      if ($(this).val().trim().length > 0) $('#sms-error').text('');
    });

    // Bulk SMS
    $('#send-all-btn').on('click', openBulkModal);
    $('#bulk-send-btn').on('click', sendBulkSms);
    $('#bulk-message').on('input', function () {
      $('#bulk-count').text($(this).val().length);
      if ($(this).val().trim().length > 0) $('#bulk-error').text('');
    });

    // Modal dismissal
    $(document).on('click', '[data-close]', function () {
      closeModal($(this).data('close') === 'sms' ? 'sms-modal' : 'bulk-modal');
    });

    $(document).on('keydown', function (event) {
      if (event.key === 'Escape') {
        closeModal('sms-modal');
        closeModal('bulk-modal');
      }
      // Ctrl/Cmd + Enter sends from either modal.
      if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        if (!$('#sms-modal').hasClass('hidden')) sendSms();
        else if (!$('#bulk-modal').hasClass('hidden')) sendBulkSms();
      }
    });

    // Logout
    $('#logout-btn').on('click', function () {
      $(this).prop('disabled', true).text('Signing out…');
      $.ajax({ url: '/auth/logout', method: 'POST', dataType: 'json' })
        .always(function () { window.location.replace('/'); });
    });
  });
})(jQuery);
