# Contact Messenger — Phase 1

Sign in with Google, pull your real Google Contacts into MySQL, browse and search them
in a dashboard, and send SMS through Twilio.

Everything here talks to real services. There is no mock data, no fake contacts and no
WhatsApp integration of any kind.

---

## Technology

| Layer | Used |
|---|---|
| Frontend | HTML, Tailwind CSS (CDN), JavaScript, jQuery 3.7 |
| Backend | Node.js 18+, Express 4 |
| Google | `googleapis` — OAuth 2.0 + People API |
| Database | MySQL 8 / MariaDB 10.4+ via `mysql2/promise` |
| Sessions | `express-session` |
| SMS | Twilio (official API) |
| Config | `dotenv` |

---

## Requirements

- Node.js 18 or newer
- MySQL 8 or MariaDB 10.4+ running locally
- A Google Cloud project with the People API enabled
- A Twilio account — optional; everything except SMS works without it

---

## Installation

```bash
npm install
cp .env.example .env      # Windows: copy .env.example .env
```

Fill in `.env`, then:

```bash
npm start      # or: npm run dev   (nodemon)
```

Open <http://localhost:3000>.

The server creates the database and all tables on first start. You do not need to run any
SQL by hand. If you prefer to do it separately: `npm run db:init`.

---

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `PORT` | no | Defaults to 3000 |
| `GOOGLE_CLIENT_ID` | yes | From Google Cloud Console |
| `GOOGLE_CLIENT_SECRET` | yes | Never commit this |
| `GOOGLE_REDIRECT_URI` | yes | Must match Google Cloud exactly |
| `DB_HOST` / `DB_PORT` / `DB_USER` / `DB_PASSWORD` / `DB_NAME` | yes | MySQL connection |
| `SESSION_SECRET` | yes | Any long random string |
| `TWILIO_ACCOUNT_SID` / `TWILIO_AUTH_TOKEN` / `TWILIO_PHONE_NUMBER` | no | SMS only |
| `DEFAULT_COUNTRY_CODE` | no | e.g. `92` turns `03001234567` into `+923001234567` |
| `CORS_ORIGIN` | no | Comma-separated allowed origins |
| `SMS_CONCURRENCY` / `SMS_BATCH_DELAY_MS` | no | Bulk-send pacing |

Generate a session secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

`.env` is listed in `.gitignore`. Confirm it is not tracked:

```bash
git check-ignore -v .env
```

---

## Google Cloud setup

1. Open <https://console.cloud.google.com/> and select or create a project.
2. **APIs & Services → Library →** search **Google People API → Enable**.
   Sign-in works without this, but syncing fails until it is on.
3. **APIs & Services → OAuth consent screen**
   - User type: External
   - Add the scope `https://www.googleapis.com/auth/contacts.readonly`
   - While the app is in Testing, add your own Gmail address under **Test users**.
     Any account not on that list gets `access_denied`.
4. **APIs & Services → Credentials → Create credentials → OAuth client ID**
   - Application type: **Web application**
   - Authorized redirect URI: `http://localhost:3000/auth/callback`
   - Copy the client ID and secret into `.env`
5. If a client secret has ever been screenshotted, pasted into a chat, or committed:
   open the client and press **Reset secret**, then update `.env`.

The redirect URI in Google Cloud and `GOOGLE_REDIRECT_URI` must be byte-identical —
`http` vs `https`, `localhost` vs `127.0.0.1` and a trailing slash all count as different.

### Scope

Only `contacts.readonly` is requested for contacts. The app never asks for write or delete
access. `userinfo.email`, `userinfo.profile` and `openid` are requested solely to know which
Google account the contacts belong to.

---

## MySQL setup

Nothing manual is required — `config/db.js` creates the database and applies
`database/schema.sql` at startup. To do it yourself:

```bash
mysql -u root -p < database/schema.sql
```

Tables: `users`, `contacts`, `sync_runs`.

---

## Twilio setup (optional)

1. Create an account at <https://www.twilio.com/>.
2. Copy the Account SID and Auth Token from the console.
3. Buy or claim an SMS-capable phone number.
4. Put all three in `.env`.

Trial accounts can only send to numbers you have verified in the Twilio console, and
international destinations must be allowed under **Messaging → Geo permissions**.

Without these variables the dashboard shows "SMS provider is not configured." and the SMS
endpoints return HTTP 503. Every other feature keeps working.

---

## API endpoints

All `/api/*` routes require an authenticated session cookie (`cm.sid`).

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Public status, no auth |
| GET | `/auth/google` | Redirect to Google consent |
| GET | `/auth/callback` | OAuth callback (Google calls this) |
| GET/POST | `/auth/logout` | Destroy the session |
| GET | `/api/me` | Current user |
| GET | `/api/contacts` | Contact list — see contract below |
| GET | `/api/contacts?search=ali` | Same shape, filtered server-side |
| POST | `/api/contacts/sync` | Fetch from Google and store |
| GET | `/api/sms/status` | Whether SMS is configured |
| POST | `/api/sms/send` | `{ "contactId": 1, "message": "…" }` |
| POST | `/api/sms/send-all` | `{ "message": "…" }` |

### `GET /api/contacts` — frozen contract

Phase 2 consumes this. Do not change it.

```json
[
  {
    "id": 1,
    "name": "Ali Khan",
    "email": "ali@gmail.com",
    "phone": "+923001234567"
  }
]
```

A bare array. Exactly `id`, `name`, `email`, `phone`. No wrapper object, no `user_id`, no
tokens, no timestamps. `email` and `phone` are `null` when absent. `[]` when there are no
contacts.

### `POST /api/contacts/sync` response

```json
{
  "success": true,
  "message": "Contacts synchronized successfully",
  "totalFetched": 120,
  "inserted": 100,
  "updated": 20,
  "unchanged": 0,
  "skipped": 0,
  "pagesFetched": 1
}
```

---

## Testing with Postman

Postman cannot complete a Google OAuth redirect, so authenticate in a browser first and
reuse the cookie.

1. Sign in at <http://localhost:3000> in your browser.
2. Open DevTools → Application → Cookies → copy the value of `cm.sid`.
3. In Postman, add a header `Cookie: cm.sid=<value>` to every request, or import the
   cookie into Postman's cookie jar for `localhost`.

| Request | Expected |
|---|---|
| `GET /health` | `200`, no auth needed |
| `GET /api/me` without cookie | `401 {"success":false,"message":"Authentication required"}` |
| `GET /api/me` with cookie | `200` with id, name, email |
| `POST /api/contacts/sync` | `200` with sync counts |
| `GET /api/contacts` | `200`, bare array in the exact shape |
| `GET /api/contacts?search=ali` | `200`, filtered, same shape |
| `POST /api/sms/send` body `{"contactId":1,"message":"Test"}` | `200`, or `503` if Twilio is unset |
| `POST /api/sms/send` with `{"message":""}` | `400` |
| `POST /api/sms/send` with another user's contactId | `404` |
| `POST /api/sms/send-all` body `{"message":"Hello"}` | `200` with total / sent / failed |
| `GET /auth/logout` | Redirect to `/`, session gone |

Duplicate-prevention check (creates a temporary user, then deletes it):

```bash
node scripts/test-duplicate-prevention.js
```

---

## Troubleshooting

**`redirect_uri_mismatch`** — the URI in Google Cloud does not match `GOOGLE_REDIRECT_URI`
character for character. Check the scheme, host and trailing slash.

**`access_denied`** — your Gmail address is not in the OAuth consent screen's test-user
list, or you pressed Cancel on the consent screen.

**Sync fails with "People API has not been used"** — enable Google People API in the
Library and wait a minute for it to propagate.

**No refresh token** — Google issues one only on the first authorisation. Remove the app at
<https://myaccount.google.com/permissions> and sign in again.

**`ER_ACCESS_DENIED_ERROR` on startup** — wrong `DB_USER` or `DB_PASSWORD`.

**`ECONNREFUSED 127.0.0.1:3306`** — MySQL is not running.

**"SMS provider is not configured."** — Twilio variables are missing from `.env`. Restart
the server after adding them.

**Twilio error 21408** — enable the destination country under Messaging → Geo permissions.

**Contacts sync but phones look wrong** — set `DEFAULT_COUNTRY_CODE` so local numbers
expand to E.164, then sync again. Existing rows update in place.

---

## Security notes

- OAuth 2.0 only. No Google API key is used for contacts, and none exists in the codebase.
- Access and refresh tokens are stored in MySQL and never sent to the browser, never placed
  in a URL, and never written to the logs.
- Sessions use httpOnly cookies with `sameSite=lax`; `secure` turns on when
  `NODE_ENV=production`.
- CORS uses an explicit origin list with credentials enabled — never a wildcard.
- Every SQL statement uses `mysql2` placeholders. No user input is concatenated into SQL.
- Every `/api` route checks `req.session.userId`, and every contact operation also verifies
  the contact belongs to that user.
- Twilio credentials stay on the server; the frontend only learns a true/false
  "configured" flag.
- `.env` is gitignored. `.env.example` holds placeholders only.

---

## Notes for production

The default session store is Express's in-memory store, which is fine for local development
but loses sessions on restart and does not work across multiple processes. Before deploying,
switch to a persistent store such as `connect-redis` or `express-mysql-session`, set
`NODE_ENV=production`, serve over HTTPS, and consider encrypting the token columns at rest.
