'use strict';

/**
 * Google OAuth 2.0 helpers.
 *
 * Credentials come from environment variables only — nothing is hard-coded and
 * nothing is ever sent to the browser.
 */

const { google } = require('googleapis');
const db = require('../config/db');

/**
 * Minimum scopes required by Phase 1:
 *   contacts.readonly  — read-only access to the user's contacts (no write/delete)
 *   userinfo.email/profile + openid — identify which local user the contacts belong to
 */
const SCOPES = [
  'https://www.googleapis.com/auth/contacts.readonly',
  'https://www.googleapis.com/auth/contacts.other.readonly',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'openid'
];

/** Raised when the user must reconnect their Google account. */
class ReauthRequiredError extends Error {
  constructor(message = 'Google connection expired. Please sign in with Google again.') {
    super(message);
    this.name = 'ReauthRequiredError';
    this.code = 'REAUTH_REQUIRED';
    this.status = 401;
  }
}

function assertConfigured() {
  const missing = ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GOOGLE_REDIRECT_URI'].filter(
    (key) => !process.env[key]
  );
  if (missing.length > 0) {
    const err = new Error(
      `Google OAuth is not configured. Missing environment variable(s): ${missing.join(', ')}. ` +
        `Copy .env.example to .env and fill them in.`
    );
    err.status = 500;
    throw err;
  }
}

function isConfigured() {
  return Boolean(
    process.env.GOOGLE_CLIENT_ID &&
      process.env.GOOGLE_CLIENT_SECRET &&
      process.env.GOOGLE_REDIRECT_URI
  );
}

/** Creates a bare OAuth2 client with no credentials attached. */
function createOAuthClient() {
  assertConfigured();
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

/**
 * Builds the consent-screen URL.
 *
 * `access_type: 'offline'` asks for a refresh token. Google only returns a
 * refresh token on the first authorisation for a given client, so we force the
 * consent screen when we do not yet hold one for this browser session
 * (`forceConsent`), and skip it otherwise to keep the UX clean.
 */
function getAuthUrl({ state, forceConsent = false } = {}) {
  const client = createOAuthClient();
  const options = {
    access_type: 'offline',
    scope: SCOPES,
    include_granted_scopes: true
  };
  if (forceConsent) options.prompt = 'consent';
  if (state) options.state = state;

  return client.generateAuthUrl(options);
}

/** Exchanges the authorization code for tokens. */
async function exchangeCodeForTokens(code) {
  const client = createOAuthClient();
  const { tokens } = await client.getToken(code);
  client.setCredentials(tokens);
  return { client, tokens };
}

/** Reads the Google profile of the authenticated user (id, email, name, picture). */
async function fetchGoogleProfile(authClient) {
  const oauth2 = google.oauth2({ version: 'v2', auth: authClient });
  const { data } = await oauth2.userinfo.get();
  return {
    googleId: data.id,
    email: data.email || null,
    name: data.name || data.email || 'Google user',
    picture: data.picture || null
  };
}

/** Persists refreshed tokens. Values are never logged. */
async function persistTokens(userId, tokens) {
  const fields = [];
  const params = [];

  if (tokens.access_token) {
    fields.push('access_token = ?');
    params.push(tokens.access_token);
  }
  if (tokens.refresh_token) {
    fields.push('refresh_token = ?');
    params.push(tokens.refresh_token);
  }
  if (tokens.expiry_date) {
    fields.push('token_expiry = ?');
    params.push(tokens.expiry_date);
  }
  if (fields.length === 0) return;

  params.push(userId);

  // `fields` holds only the fixed literals assigned above ("access_token = ?",
  // etc.) — no user input is ever interpolated. All values stay parameterised.
  await db.query(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, params);
}

/**
 * Builds an OAuth2 client already loaded with the stored credentials of a local
 * user. googleapis refreshes the access token automatically when it has expired
 * and a refresh token is present; the `tokens` event writes the new values back
 * to MySQL so the refresh survives a restart.
 */
async function getAuthenticatedClientForUser(userId) {
  const rows = await db.query(
    'SELECT id, access_token, refresh_token, token_expiry FROM users WHERE id = ? LIMIT 1',
    [userId]
  );

  const user = rows[0];
  if (!user) throw new ReauthRequiredError('User not found. Please sign in again.');
  if (!user.access_token && !user.refresh_token) {
    throw new ReauthRequiredError('No Google credentials stored. Please connect Google again.');
  }

  const client = createOAuthClient();
  client.setCredentials({
    access_token: user.access_token || undefined,
    refresh_token: user.refresh_token || undefined,
    expiry_date: user.token_expiry ? Number(user.token_expiry) : undefined
  });

  client.on('tokens', (tokens) => {
    persistTokens(userId, tokens).catch((err) => {
      console.error('[auth] Failed to persist refreshed Google tokens:', err.message);
    });
    console.log(`[auth] Google access token refreshed for user ${userId}`);
  });

  return client;
}

/**
 * Maps a Google API failure onto a ReauthRequiredError when the grant is dead,
 * so callers can clear the session instead of showing a raw 400.
 */
function isInvalidGrant(err) {
  const payload = err && (err.response ? err.response.data : null);
  const reason = (payload && (payload.error || payload.error_description)) || err.message || '';
  return /invalid_grant|invalid_token|unauthorized_client|Token has been expired or revoked/i.test(
    String(reason)
  );
}

/** Removes stored tokens after a revoked/expired grant. */
async function clearStoredTokens(userId) {
  await db.query(
    'UPDATE users SET access_token = NULL, refresh_token = NULL, token_expiry = NULL WHERE id = ?',
    [userId]
  );
}

module.exports = {
  SCOPES,
  ReauthRequiredError,
  isConfigured,
  assertConfigured,
  createOAuthClient,
  getAuthUrl,
  exchangeCodeForTokens,
  fetchGoogleProfile,
  getAuthenticatedClientForUser,
  persistTokens,
  isInvalidGrant,
  clearStoredTokens
};