'use strict';

/**
 * Google People API access.
 *
 * Uses people.connections.list with resourceName "people/me" and follows
 * nextPageToken until every page has been retrieved. One request never returns
 * the whole address book.
 */

const { google } = require('googleapis');

const PERSON_FIELDS = 'names,emailAddresses,phoneNumbers';
const PAGE_SIZE = 1000; // People API maximum for connections.list

/**
 * Picks the entry marked primary, otherwise the first non-empty entry.
 */
function pickPrimary(list, valueKey) {
  if (!Array.isArray(list) || list.length === 0) return null;

  const primary = list.find(
    (item) => item && item.metadata && item.metadata.primary && item[valueKey]
  );
  const chosen = primary || list.find((item) => item && item[valueKey]);
  return chosen || null;
}

function cleanString(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim().replace(/\s+/g, ' ');
  return trimmed.length > 0 ? trimmed : null;
}

/**
 * Normalises a phone number for storage.
 *
 * Google's `canonicalForm` is already E.164 when it can determine the region,
 * so it is preferred. Otherwise digits are kept, a leading "+" is preserved,
 * and an optional DEFAULT_COUNTRY_CODE converts a local number such as
 * 0300 1234567 into +923001234567. Nothing is invented: if there are too few
 * digits to be a real number, null is returned.
 */
function normalisePhone(rawValue, canonicalForm) {
  const canonical = cleanString(canonicalForm);
  if (canonical && /^\+[1-9]\d{6,15}$/.test(canonical)) return canonical;

  const raw = cleanString(rawValue);
  if (!raw) return null;

  // Strip everything except digits and a single leading plus.
  let value = raw.replace(/[^\d+]/g, '');
  const hasPlus = value.startsWith('+');
  value = value.replace(/\+/g, '');
  if (value.length === 0) return null;

  if (hasPlus) {
    return value.length >= 7 ? `+${value}` : null;
  }

  const countryCode = (process.env.DEFAULT_COUNTRY_CODE || '').replace(/[^\d]/g, '');
  if (countryCode) {
    const national = value.replace(/^0+/, '');
    if (national.length >= 7) return `+${countryCode}${national}`;
    return null;
  }

  // No country code configured — store the digits as-is so nothing is lost.
  return value.length >= 7 ? value : null;
}

function normaliseEmail(rawValue) {
  const email = cleanString(rawValue);
  if (!email) return null;
  return email.toLowerCase();
}

/**
 * Converts a People API `person` into the internal shape:
 *   { googleResourceName, name, email, phone }
 *
 * Returns null for records that carry no usable information at all.
 * Missing fields never throw.
 */
function normalisePerson(person) {
  if (!person || typeof person !== 'object') return null;

  const googleResourceName = cleanString(person.resourceName);

  // A name entry may carry displayName, or only givenName/familyName.
  const nameEntry =
    pickPrimary(person.names, 'displayName') ||
    pickPrimary(person.names, 'givenName') ||
    pickPrimary(person.names, 'familyName');

  let name = nameEntry ? cleanString(nameEntry.displayName) : null;
  if (!name && nameEntry) {
    name = cleanString([nameEntry.givenName, nameEntry.middleName, nameEntry.familyName]
      .filter(Boolean)
      .join(' '));
  }

  const emailEntry = pickPrimary(person.emailAddresses, 'value');
  const email = emailEntry ? normaliseEmail(emailEntry.value) : null;

  const phoneEntry = pickPrimary(person.phoneNumbers, 'value');
  const phone = phoneEntry ? normalisePhone(phoneEntry.value, phoneEntry.canonicalForm) : null;

  // Fall back to a contactable identifier for display; never fabricate one.
  if (!name) name = email || phone || 'Unnamed contact';

  if (!googleResourceName && !email && !phone) return null;

  return { googleResourceName, name, email, phone };
}

/**
 * Fetches every page of the user's manually-saved Google Contacts
 * (people.connections.list — resourceName "people/me").
 */
async function fetchSavedConnections(people) {
  const contacts = [];
  let pageToken;
  let pages = 0;
  let rawCount = 0;

  do {
    const response = await people.people.connections.list({
      resourceName: 'people/me',
      personFields: PERSON_FIELDS,
      pageSize: PAGE_SIZE,
      pageToken
    });

    pages += 1;
    const connections = response.data.connections || [];
    rawCount += connections.length;

    for (const person of connections) {
      const normalised = normalisePerson(person);
      if (normalised) contacts.push(normalised);
    }

    // Safe development logging only — no tokens, no contact contents.
    console.log(`[contacts] Saved contacts — page ${pages} (${connections.length} connections)`);

    pageToken = response.data.nextPageToken || undefined;
  } while (pageToken);

  return { contacts, pages, rawCount };
}

/**
 * Fetches every page of "Other contacts" — people Google auto-saved from
 * Gmail interactions that the user never explicitly added to their address
 * book. This is a separate endpoint with its own scope
 * (contacts.other.readonly) and its own field parameter name (readMask
 * instead of personFields). For most Gmail accounts this list is larger than
 * the manually-saved one.
 */
async function fetchOtherContacts(people) {
  const contacts = [];
  let pageToken;
  let pages = 0;
  let rawCount = 0;

  do {
    const response = await people.otherContacts.list({
      readMask: PERSON_FIELDS,
      pageSize: PAGE_SIZE,
      pageToken
    });

    pages += 1;
    const others = response.data.otherContacts || [];
    rawCount += others.length;

    for (const person of others) {
      const normalised = normalisePerson(person);
      if (normalised) contacts.push(normalised);
    }

    console.log(`[contacts] Other contacts — page ${pages} (${others.length} connections)`);

    pageToken = response.data.nextPageToken || undefined;
  } while (pageToken);

  return { contacts, pages, rawCount };
}

/**
 * Fetches every page of both the user's saved contacts and their "Other
 * contacts" (Gmail-derived, never manually saved), merged into one list.
 * Both categories go through the same normalisation and the same dedupe
 * key logic downstream in contactStore, so overlap between the two lists
 * collapses to one row instead of duplicating.
 *
 * @param {import('google-auth-library').OAuth2Client} authClient
 * @returns {Promise<{contacts: Array, pages: number, rawCount: number}>}
 */
async function fetchAllGoogleContacts(authClient) {
  const people = google.people({ version: 'v1', auth: authClient });

  const saved = await fetchSavedConnections(people);
  const other = await fetchOtherContacts(people);

  const contacts = [...saved.contacts, ...other.contacts];
  const pages = saved.pages + other.pages;
  const rawCount = saved.rawCount + other.rawCount;

  console.log(
    `[contacts] Total fetched: ${contacts.length} ` +
      `(saved: ${saved.contacts.length}, other: ${other.contacts.length})`
  );

  return { contacts, pages, rawCount };
}

module.exports = {
  PERSON_FIELDS,
  fetchAllGoogleContacts,
  fetchSavedConnections,
  fetchOtherContacts,
  normalisePerson,
  normalisePhone,
  normaliseEmail
};