'use strict';

/**
 * Persistence for synchronised contacts.
 *
 * Kept separate from the route so the duplicate-prevention logic can be tested
 * on its own (see scripts/test-duplicate-prevention.js).
 */

const db = require('../config/db');

/**
 * Identity key for a contact.
 *
 * Primary:  the People API resource name — stable for the lifetime of the
 *           contact, so re-syncing matches the same row every time.
 * Fallback: normalised email + phone, used only when a record has no resource
 *           name. The name is never part of the key, because different people
 *           share names.
 */
function buildDedupeKey(contact) {
  if (contact.googleResourceName) return contact.googleResourceName;

  const email = (contact.email || '').trim().toLowerCase();
  const phone = (contact.phone || '').replace(/[^\d+]/g, '');
  if (!email && !phone) return null;

  return `fallback:${email}|${phone}`;
}

/**
 * Collapses a fetched batch so two records that resolve to the same identity
 * cannot both be inserted in one run.
 *
 * @returns {{unique: Map<string, object>, skipped: number}}
 */
function dedupeBatch(contacts) {
  const unique = new Map();
  let skipped = 0;

  for (const contact of contacts) {
    const key = buildDedupeKey(contact);
    if (!key) {
      skipped += 1;
      continue;
    }
    unique.set(key, { ...contact, dedupeKey: key });
  }

  return { unique, skipped };
}

/**
 * Inserts new contacts and updates changed ones inside a single transaction.
 * Running it twice with the same input produces zero inserts the second time.
 *
 * @param {number} userId
 * @param {Array<{googleResourceName?:string,name?:string,email?:string,phone?:string}>} contacts
 * @returns {Promise<{total:number, inserted:number, updated:number, unchanged:number, skipped:number}>}
 */
async function upsertContacts(userId, contacts) {
  const { unique, skipped } = dedupeBatch(contacts);

  const stats = await db.withTransaction(async (connection) => {
    const [existingRows] = await connection.execute(
      'SELECT id, dedupe_key, name, email, phone, google_resource_name FROM contacts WHERE user_id = ?',
      [userId]
    );

    const existing = new Map(existingRows.map((row) => [row.dedupe_key, row]));

    let inserted = 0;
    let updated = 0;
    let unchanged = 0;

    for (const contact of unique.values()) {
      const current = existing.get(contact.dedupeKey);

      if (!current) {
        // ON DUPLICATE KEY UPDATE is a second line of defence: the unique index
        // on (user_id, dedupe_key) makes a concurrent sync safe too.
        await connection.execute(
          `INSERT INTO contacts (user_id, google_resource_name, dedupe_key, name, email, phone)
           VALUES (?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             name = VALUES(name),
             email = VALUES(email),
             phone = VALUES(phone),
             google_resource_name = VALUES(google_resource_name)`,
          [
            userId,
            contact.googleResourceName || null,
            contact.dedupeKey,
            contact.name || null,
            contact.email || null,
            contact.phone || null
          ]
        );
        inserted += 1;
        continue;
      }

      const changed =
        (current.name || null) !== (contact.name || null) ||
        (current.email || null) !== (contact.email || null) ||
        (current.phone || null) !== (contact.phone || null) ||
        (current.google_resource_name || null) !== (contact.googleResourceName || null);

      if (!changed) {
        unchanged += 1;
        continue;
      }

      await connection.execute(
        `UPDATE contacts
            SET name = ?, email = ?, phone = ?, google_resource_name = ?
          WHERE id = ? AND user_id = ?`,
        [
          contact.name || null,
          contact.email || null,
          contact.phone || null,
          contact.googleResourceName || null,
          current.id,
          userId
        ]
      );
      updated += 1;
    }

    return { inserted, updated, unchanged };
  });

  return { total: unique.size, skipped, ...stats };
}

/** Records a sync run for auditing. Never stores contact contents. */
async function recordSyncRun(userId, { pages, total, inserted, updated, skipped }) {
  await db.query(
    `INSERT INTO sync_runs (user_id, pages_fetched, total_fetched, inserted_count, updated_count, skipped_count)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, pages || 0, total || 0, inserted || 0, updated || 0, skipped || 0]
  );
}

module.exports = { buildDedupeKey, dedupeBatch, upsertContacts, recordSyncRun };
