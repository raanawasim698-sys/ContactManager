'use strict';

const MAX_MESSAGE_LENGTH = 1600;
const BATCH_CONCURRENCY = Number(process.env.SMS_CONCURRENCY || 3);
const BATCH_DELAY_MS = Number(process.env.SMS_BATCH_DELAY_MS || 250);

let cachedClient = null;

function isConfigured() {
  return Boolean(
    process.env.VONAGE_API_KEY &&
      process.env.VONAGE_API_SECRET &&
      process.env.VONAGE_FROM
  );
}

function getClient() {
  if (!isConfigured()) {
    const err = new Error('SMS provider is not configured.');
    err.code = 'SMS_NOT_CONFIGURED';
    err.status = 503;
    throw err;
  }
  if (!cachedClient) {
    const { Vonage } = require('@vonage/server-sdk');
    const { Auth } = require('@vonage/auth');
    cachedClient = new Vonage(
      new Auth({
        apiKey: process.env.VONAGE_API_KEY,
        apiSecret: process.env.VONAGE_API_SECRET
      })
    );
  }
  return cachedClient;
}

function isSendablePhone(phone) {
  if (typeof phone !== 'string') return false;
  const digits = phone.replace(/[^\d]/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

function validateMessage(message) {
  if (typeof message !== 'string' || message.trim().length === 0) {
    const err = new Error('Message cannot be empty.');
    err.status = 400;
    err.code = 'EMPTY_MESSAGE';
    throw err;
  }
  const trimmed = message.trim();
  if (trimmed.length > MAX_MESSAGE_LENGTH) {
    const err = new Error(`Message is too long. Maximum ${MAX_MESSAGE_LENGTH} characters.`);
    err.status = 400;
    err.code = 'MESSAGE_TOO_LONG';
    throw err;
  }
  return trimmed;
}

/** Vonage returns a numeric status string per message, not an HTTP error. */
function describeProviderStatus(status, errorText) {
  switch (status) {
    case '1':
      return 'Vonage is temporarily unable to process this message. Try again shortly.';
    case '2':
      return 'Vonage rejected the message.';
    case '4':
      return 'Vonage rejected the credentials. Check VONAGE_API_KEY and VONAGE_API_SECRET.';
    case '6':
      return 'That phone number is not valid for SMS.';
    case '9':
      return 'Insufficient Vonage account balance.';
    case '15':
      return 'This destination number has not been allow-listed for your Vonage trial account.';
    case '29':
      return 'Non-whitelisted destination — add this number as a test number in the Vonage dashboard.';
    default:
      return errorText || 'The SMS provider rejected the request.';
  }
}

async function sendSms(to, message) {
  const body = validateMessage(message);

  if (!isSendablePhone(to)) {
    const err = new Error('Recipient phone number is missing or invalid.');
    err.status = 400;
    err.code = 'INVALID_PHONE';
    throw err;
  }

  const client = getClient();
  // Vonage wants digits only, no leading +
  const to_digits = to.replace(/[^\d]/g, '');

  let resp;
  try {
    resp = await client.sms.send({
      to: to_digits,
      from: process.env.VONAGE_FROM,
      text: body
    });
  } catch (err) {
    const wrapped = new Error(err.message || 'The SMS provider rejected the request.');
    wrapped.status = 502;
    wrapped.code = 'SMS_PROVIDER_ERROR';
    throw wrapped;
  }

  const result = resp.messages && resp.messages[0];
  if (!result || result.status !== '0') {
    const wrapped = new Error(
      describeProviderStatus(result && result.status, result && result['error-text'])
    );
    wrapped.status = 502;
    wrapped.code = 'SMS_PROVIDER_ERROR';
    wrapped.providerCode = result && result.status;
    throw wrapped;
  }

  return { sid: result['message-id'], status: 'sent' };
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function sendBulkSms(recipients, message) {
  const body = validateMessage(message);
  const results = { total: recipients.length, sent: 0, failed: 0, failures: [] };
  const queue = [...recipients];

  async function worker() {
    while (queue.length > 0) {
      const recipient = queue.shift();
      if (!recipient) break;
      try {
        await sendSms(recipient.phone, body);
        results.sent += 1;
      } catch (err) {
        results.failed += 1;
        if (results.failures.length < 25) {
          results.failures.push({ contactId: recipient.id, name: recipient.name, reason: err.message });
        }
      }
      if (BATCH_DELAY_MS > 0) await sleep(BATCH_DELAY_MS);
    }
  }

  const workers = Array.from({ length: Math.max(1, Math.min(BATCH_CONCURRENCY, 10)) }, worker);
  await Promise.all(workers.map((fn) => fn()));
  return results;
}

module.exports = { isConfigured, isSendablePhone, validateMessage, sendSms, sendBulkSms, MAX_MESSAGE_LENGTH };