-- Contact Messenger — Phase 1 schema
-- Safe to run repeatedly: every statement is IF NOT EXISTS.
-- The server applies this file automatically at startup (config/db.js).

CREATE DATABASE IF NOT EXISTS contact_messenger
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE contact_messenger;

-- ---------------------------------------------------------------------------
-- users
-- One row per Google account that has connected. OAuth tokens are stored here
-- and never leave the backend.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  google_id      VARCHAR(64)  NOT NULL,
  name           VARCHAR(255) NULL,
  email          VARCHAR(255) NULL,
  picture        VARCHAR(512) NULL,
  access_token   TEXT         NULL,
  refresh_token  TEXT         NULL,
  token_expiry   BIGINT       NULL,
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_google_id (google_id),
  KEY idx_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- contacts
-- Duplicate prevention strategy:
--   dedupe_key = google_resource_name when the People API supplies one
--                (it always does for `people.connections.list`),
--                otherwise a normalised "email|phone" fallback key.
--   UNIQUE (user_id, dedupe_key) is what makes re-syncing idempotent.
--   A second UNIQUE (user_id, google_resource_name) enforces the contract
--   requested in the spec; MySQL permits repeated NULLs in a unique index,
--   so contacts without a resource name are unaffected.
-- Name alone is never used as an identity key — different people share names.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacts (
  id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id               INT UNSIGNED NOT NULL,
  google_resource_name  VARCHAR(255) NULL,
  dedupe_key            VARCHAR(255) NOT NULL,
  name                  VARCHAR(255) NULL,
  email                 VARCHAR(255) NULL,
  phone                 VARCHAR(64)  NULL,
  created_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_contacts_user_dedupe (user_id, dedupe_key),
  UNIQUE KEY uq_contacts_user_resource (user_id, google_resource_name),
  KEY idx_contacts_user (user_id),
  KEY idx_contacts_name (name),
  KEY idx_contacts_email (email),
  KEY idx_contacts_phone (phone),
  CONSTRAINT fk_contacts_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- sync_runs
-- Lightweight audit of each synchronisation, useful for debugging pagination
-- and for the Phase 2 handoff. Contains no personal data beyond counts.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_runs (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id        INT UNSIGNED NOT NULL,
  pages_fetched  INT UNSIGNED NOT NULL DEFAULT 0,
  total_fetched  INT UNSIGNED NOT NULL DEFAULT 0,
  inserted_count INT UNSIGNED NOT NULL DEFAULT 0,
  updated_count  INT UNSIGNED NOT NULL DEFAULT 0,
  skipped_count  INT UNSIGNED NOT NULL DEFAULT 0,
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_sync_runs_user (user_id, created_at),
  CONSTRAINT fk_sync_runs_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
