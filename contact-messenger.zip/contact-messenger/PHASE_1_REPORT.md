# Phase 1 Report — Contact Messenger

## 1. Objective

Authenticate a user with Google, read their real Google Contacts through the People API,
store them in MySQL without duplicating on repeated sync, expose them through a fixed REST
contract, present them in an HTML/Tailwind/jQuery dashboard, and send SMS through an
official provider.

SMS only. No WhatsApp, no browser automation, no mock data.

---

## 2. Implemented features

- Google OAuth 2.0 sign-in with the read-only contacts scope
- Local user records created and updated from the Google profile
- Server-side token storage with automatic access-token refresh
- Full-pagination contact fetch through `people.connections.list`
- Contact normalisation covering missing, empty and multi-valued fields
- Idempotent upsert into MySQL with a unique dedupe key
- `GET /api/contacts` in the exact contract shape
- Server-side search on name, email and phone
- Dashboard with search, sync, per-contact SMS and bulk SMS
- Twilio SMS with graceful degradation when unconfigured
- Session authentication on every API route plus per-record ownership checks

---

## 3. Google OAuth implementation

`services/googleAuth.js`, `routes/auth.js`

Scopes requested:

```
https://www.googleapis.com/auth/contacts.readonly
https://www.googleapis.com/auth/userinfo.email
https://www.googleapis.com/auth/userinfo.profile
openid
```

`contacts.readonly` is the minimum needed to read contacts. Write and delete scopes are
never requested. The identity scopes exist only to attach contacts to the right local user.

**`GET /auth/google`** generates a random `state` value, stores it in the session, and
redirects to Google with `access_type=offline`. `prompt=consent` is sent only when this
browser has not connected before, so the first authorisation yields a refresh token without
forcing the consent screen on every later sign-in.

**`GET /auth/callback`**

1. Rejects the request if Google returned an error or no code
2. Compares `state` against the session value (CSRF protection)
3. Exchanges the code for tokens
4. Reads the Google profile through the userinfo endpoint
5. Inserts or updates the `users` row, preserving an existing refresh token when Google
   does not issue a new one
6. Writes only `req.session.userId` — no token ever reaches the browser
7. Redirects to `/dashboard.html`

Logging is limited to `OAuth successful — Google user authenticated. User ID: N`. Client
secrets, access tokens and refresh tokens are never logged, never returned in a response
body, and never placed in a query string.

---

## 4. Google People API implementation

`services/googleContacts.js`

```
people.people.connections.list({
  resourceName: 'people/me',
  personFields: 'names,emailAddresses,phoneNumbers',
  pageSize: 1000,
  pageToken
})
```

Normalisation rules:

| Field | Rule |
|---|---|
| Name | Entry flagged primary, else the first with a `displayName`, else `givenName middleName familyName`, else the email, else the phone, else `Unnamed contact` |
| Email | Primary entry, lowercased; `null` when absent |
| Phone | Google's `canonicalForm` when it is valid E.164, else digits with `+` preserved, expanded using `DEFAULT_COUNTRY_CODE` when set; `null` when absent or too short |

Nothing is fabricated. A phone field containing non-numeric text yields `null` rather than a
guess, and an email is never treated as a phone number. Records with no resource name, no
email and no phone are skipped.

---

## 5. Pagination implementation

```js
let pageToken;
do {
  const response = await people.people.connections.list({ ..., pageToken });
  // process response.data.connections
  pageToken = response.data.nextPageToken || undefined;
} while (pageToken);
```

The loop continues until Google stops returning `nextPageToken`. There is no assumption
about the number of contacts. Development logging prints `Fetched page N (M connections)`
and a final total — no tokens, no contact contents.

Verified with a stubbed People API returning three pages (1000 / 1000 / 37):

```
[contacts] Fetched page 1 (1000 connections)
[contacts] Fetched page 2 (1000 connections)
[contacts] Fetched page 3 (37 connections)
[contacts] Total contacts fetched: 2037
Pages requested with tokens: FIRST -> tok2 -> tok3
PASS pagination: true
```

---

## 6. MySQL schema

`database/schema.sql` — applied automatically at startup.

**users** — `id`, `google_id` (unique), `name`, `email`, `picture`, `access_token`,
`refresh_token`, `token_expiry`, `created_at`, `updated_at`

**contacts** — `id`, `user_id` (FK → `users.id`, cascade delete), `google_resource_name`,
`dedupe_key`, `name`, `email`, `phone`, `created_at`, `updated_at`

Indexes: `UNIQUE (user_id, dedupe_key)`, `UNIQUE (user_id, google_resource_name)`,
plus non-unique indexes on `user_id`, `name`, `email` and `phone`.

**sync_runs** — per-sync counts for auditing. Contains no personal data.

---

## 7. Duplicate prevention

`services/contactStore.js`

The identity key is the People API resource name, which is stable across syncs. When a
record has no resource name, the fallback is `fallback:<lowercased email>|<digits of phone>`.
The name is never part of the key, because different people share names.

Three layers:

1. The incoming batch is collapsed into a `Map` keyed by dedupe key, so one run cannot
   insert the same identity twice.
2. Existing rows are read once, and each contact is routed to INSERT, UPDATE or skipped as
   unchanged.
3. `UNIQUE (user_id, dedupe_key)` plus `ON DUPLICATE KEY UPDATE` protects against
   concurrent syncs at the database level.

The whole upsert runs in one transaction.

---

## 8. API endpoints

| Method | Path | Auth | Response |
|---|---|---|---|
| GET | `/health` | none | `{ status, googleOAuthConfigured, smsConfigured }` |
| GET | `/auth/google` | none | 302 to Google |
| GET | `/auth/callback` | none | 302 to `/dashboard.html` |
| GET/POST | `/auth/logout` | none | Redirect or `{ success: true }` |
| GET | `/api/me` | session | `{ id, name, email, picture, contactCount, smsConfigured }` |
| GET | `/api/contacts` | session | Bare array — frozen contract |
| POST | `/api/contacts/sync` | session | Sync statistics |
| GET | `/api/sms/status` | session | `{ success, configured }` |
| POST | `/api/sms/send` | session | `{ success, message, contactId, status }` |
| POST | `/api/sms/send-all` | session | `{ success, total, sent, failed, failures }` |

Status codes: `200` success, `400` bad request, `401` unauthenticated or revoked Google
grant, `404` not found or not owned by the user, `429` Google rate limit, `502` SMS provider
failure, `503` SMS not configured, `500` unexpected. 500-level responses carry a generic
message; stack traces stay in the server logs.

---

## 9. Frontend implementation

`public/index.html` — login page. Product name, the subtitle "Sync your Google contacts and
manage messaging from one place.", and a Continue with Google button linking to
`/auth/google`. No password field exists anywhere: Google performs all authentication.
OAuth error messages arrive as a query parameter and are displayed, then cleared from the
address bar.

`public/dashboard.html` + `public/js/dashboard.js` — navbar with the signed-in user and a
log-out button, contact count, sync button, search field, contact list, per-contact Send SMS
button, Send SMS to all, two modals, and toast notifications. Contacts are loaded from
`GET /api/contacts` and rendered from the response; nothing is hard-coded. Missing values
render as "No email" and "No phone number", and a contact without a phone shows no SMS
button.

Search is client-side jQuery filtering on name, email and phone, updating instantly with a
clear button. Digits-only comparison means `0300 123` also finds `+923001234567`.

Animations are limited to Tailwind transitions and small CSS keyframes — modal fade and
scale, toast slide, spinner, one list entrance. No animation library. All motion collapses
under `prefers-reduced-motion`.

Layout is responsive: a four-column grid on desktop that stacks on mobile.

---

## 10. SMS implementation

`services/smsService.js`, `routes/sms.js` — Twilio, the official provider API.

`POST /api/sms/send` authenticates the session, validates `contactId` and the message,
confirms the contact belongs to this user, confirms a usable phone number exists, then
sends. `POST /api/sms/send-all` loads the user's contacts, filters to those with usable
numbers, and sends with bounded concurrency and a delay between messages so a large batch
never blocks the server or trips Twilio's rate limits.

Provider errors are translated into plain sentences (invalid number, geo permissions,
unsubscribed recipient, bad credentials) rather than surfacing raw Twilio codes.

When credentials are absent, both endpoints return
`503 { "success": false, "message": "SMS provider is not configured." }` and the dashboard
shows a banner. Everything else in Phase 1 continues to work.

There is no WhatsApp code in this project: no `wa.me` links, no WhatsApp Web automation, no
unofficial API, no browser automation.

---

## 11. Security

Audit performed across the whole tree.

- No hard-coded credentials, API keys, tokens or secrets anywhere in source
- No Google API key is used for contacts — OAuth 2.0 only
- Minimum scope: `contacts.readonly`
- Tokens stored server-side only; never in responses, URLs or logs
- `express-session` with httpOnly cookies, `sameSite=lax`, `secure` in production
- CORS restricted to an explicit origin list with credentials enabled; no wildcard
- Every SQL statement parameterised; `LIKE` wildcards in search input are escaped
- `requireAuth` on every `/api` route, plus ownership checks on every contact operation
- Twilio credentials never leave the backend; the frontend receives only a boolean
- All rendered contact values pass through HTML escaping before insertion into the DOM
- OAuth `state` parameter validated to prevent CSRF on the callback
- `.env` gitignored; `.env.example` contains placeholders only

---

## 12. Testing

Executed against Node 22 and a live MariaDB 10.11 instance.

**Duplicate prevention** — `node scripts/test-duplicate-prevention.js`, 7/7 passed:

```
First sync:   inserted 4, skipped 1 (no identity), rows 4
Second sync:  inserted 0, unchanged 4,             rows 4
Third sync:   inserted 0, updated 1,               rows 4
              new phone stored: +19999999999
```

**Contract** — live route against real MySQL returned a bare array whose only keys were
`email, id, name, phone`. `?search=zed` filtered correctly. A `' OR 1=1 --` search returned
`[]`, confirming parameterisation.

**Pagination** — 3 stubbed pages, tokens followed in order, 2037 contacts collected.

**Normalisation** — verified for: no name, given/family only, multiple emails with a
non-first primary, multiple phones with primary and canonical forms, empty arrays, entirely
empty person, `null` person, and non-numeric phone text. None threw; none invented data.

**Endpoints** —

```
GET  /health                       200
GET  /                             200
GET  /dashboard.html               200
GET  /api/me                       401  Authentication required
GET  /api/contacts                 401  Authentication required
POST /api/contacts/sync            401  Authentication required
POST /api/sms/send                 401  Authentication required
POST /api/sms/send-all             401  Authentication required
GET  /api/does-not-exist           404  Endpoint not found
GET  /auth/google (unconfigured)   302  with a readable error message
```

**SMS paths** —

```
No credentials, send / send-all    503  SMS provider is not configured.
Empty message                      400  Message cannot be empty.
Missing contactId                  400  A valid contactId is required.
Another user's contact             404  Contact not found.
Contact without a phone            400  <name> has no usable phone number.
Bad provider credentials           502  translated provider message
send-all, nobody has a phone       400  No contacts have a usable phone number.
```

**Startup** — database and all three tables created automatically; clear warnings when
Google or Twilio configuration is missing; clean exit with a readable message when MySQL is
unreachable.

---

## 13. Known limitations

1. Sessions use the in-memory store. Restarting the server signs everyone out, and it does
   not work across multiple processes. Swap in Redis or a MySQL session store for production.
2. OAuth tokens are stored in plaintext columns. Encrypt at rest before production.
3. Phone normalisation is rule-based rather than a full E.164 parser. `libphonenumber-js`
   would handle ambiguous regions better.
4. Only the primary email and phone are stored, per the agreed contract. Google may hold
   several of each.
5. Deletions in Google are not propagated. A contact removed upstream stays in the database
   until deleted manually. Sync tokens would enable this later.
6. Sync is synchronous within the request. An address book in the tens of thousands would be
   better handled by a background job.
7. Bulk SMS results are returned only at the end; there is no live per-recipient progress.
8. Tailwind is loaded from the CDN, which prints a production warning in the console. Move
   to the Tailwind CLI build before deploying.

---

## 14. Phase 2 handoff

**Base URL** — `http://localhost:3000`

**Endpoint** — `GET /api/contacts`

**Method** — `GET`

**Authentication** — an authenticated session. Send the `cm.sid` cookie; use
`credentials: 'include'` from a browser client, and add the origin to `CORS_ORIGIN` if
Phase 2 runs on a different port.

**Response**

```json
[
  {
    "id": 1,
    "name": "Ali Khan",
    "email": "ali@gmail.com",
    "phone": "+923001234567"
  }
]
```

`id` is the MySQL primary key and is stable — use it as the foreign key for Phase 2 tables.
`email` and `phone` are `null` when unavailable. An empty list returns `[]`. Errors return
`401 { "success": false, "message": "Authentication required" }`.

**Contract rules for Phase 2:** do not change the field names, do not add fields, do not
wrap the array in an object. Phase 2 consumes this endpoint as-is with no changes to
Phase 1. Anything Phase 2 needs beyond these four fields should be added as a new endpoint.

Also available and stable: `GET /api/me`, `POST /api/contacts/sync`,
`GET /api/contacts?search=<term>`.
