#!/usr/bin/env node
'use strict';

/**
 * Creates the database and applies database/schema.sql.
 * The server does this automatically at startup; this script is here for when
 * you want to prepare the database separately.
 *
 * Run:  npm run db:init
 */

require('dotenv').config();

const db = require('../config/db');

(async () => {
  try {
    const info = await db.initDatabase();
    console.log(`Database ready — ${info.host}:${info.port}/${info.database}`);

    const tables = await db.query(
      'SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME',
      [info.database]
    );
    tables.forEach((table) => console.log(`  · ${table.name}`));

    await db.closeDatabase();
    process.exit(0);
  } catch (err) {
    console.error('Database setup failed.');
    console.error(err.message);
    process.exit(1);
  }
})();
