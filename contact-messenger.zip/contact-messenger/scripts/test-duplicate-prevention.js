#!/usr/bin/env node
'use strict';

/**
 * Duplicate-prevention check (Step 33 of the Phase 1 spec).
 *
 * This is a developer tool, not part of the running application. It creates a
 * throwaway user, runs the same upsert twice, asserts the row count did not
 * grow, verifies that a changed field updates in place, and then deletes
 * everything it created. No mock data ever reaches the real application.
 *
 * Run:  node scripts/test-duplicate-prevention.js
 */

require('dotenv').config();

const db = require('../config/db');
const contactStore = require('../services/contactStore');

const TEST_GOOGLE_ID = '__dedupe_check__';

function line(label, value) {
  console.log(`  ${label.padEnd(34)} ${value}`);
}

async function countContacts(userId) {
  const [row] = await db.query('SELECT COUNT(*) AS total FROM contacts WHERE user_id = ?', [userId]);
  return Number(row.total);
}

async function main() {
  await db.initDatabase();
  console.log('Duplicate-prevention check\n');

  // Clean up any leftovers from a previous run.
  await db.query('DELETE FROM users WHERE google_id = ?', [TEST_GOOGLE_ID]);

  const pool = db.getPool();
  const [insert] = await pool.execute(
    'INSERT INTO users (google_id, name, email) VALUES (?, ?, ?)',
    [TEST_GOOGLE_ID, 'Duplicate check user', 'dedupe-check@example.invalid']
  );
  const userId = insert.insertId;

  let failures = 0;
  const assert = (label, actual, expected) => {
    const ok = actual === expected;
    if (!ok) failures += 1;
    console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${label} — expected ${expected}, got ${actual}`);
  };

  try {
    // A batch shaped exactly like normalised People API output, including the
    // awkward cases: no email, no phone, no resource name, and a duplicate.
    const batch = [
      { googleResourceName: 'people/c1', name: 'Contact One', email: 'one@example.invalid', phone: '+10000000001' },
      { googleResourceName: 'people/c2', name: 'Contact Two', email: null, phone: '+10000000002' },
      { googleResourceName: 'people/c3', name: 'Contact Three', email: 'three@example.invalid', phone: null },
      { googleResourceName: null, name: 'No Resource Name', email: 'four@example.invalid', phone: '+10000000004' },
      { googleResourceName: 'people/c1', name: 'Contact One', email: 'one@example.invalid', phone: '+10000000001' },
      { googleResourceName: null, name: 'Nothing Usable', email: null, phone: null }
    ];

    console.log('First sync');
    const first = await contactStore.upsertContacts(userId, batch);
    line('inserted', first.inserted);
    line('updated', first.updated);
    line('skipped (no identity)', first.skipped);
    const countAfterFirst = await countContacts(userId);
    line('rows in contacts table', countAfterFirst);

    console.log('\nSecond sync — identical input');
    const second = await contactStore.upsertContacts(userId, batch);
    line('inserted', second.inserted);
    line('updated', second.updated);
    line('unchanged', second.unchanged);
    const countAfterSecond = await countContacts(userId);
    line('rows in contacts table', countAfterSecond);

    console.log('\nThird sync — one phone number changed upstream');
    const changed = batch.map((c) =>
      c.googleResourceName === 'people/c2' ? { ...c, phone: '+19999999999' } : c
    );
    const third = await contactStore.upsertContacts(userId, changed);
    const countAfterThird = await countContacts(userId);
    const [updatedRow] = await db.query(
      'SELECT phone FROM contacts WHERE user_id = ? AND google_resource_name = ?',
      [userId, 'people/c2']
    );
    line('inserted', third.inserted);
    line('updated', third.updated);
    line('rows in contacts table', countAfterThird);
    line('new phone stored', updatedRow.phone);

    console.log('\nResults');
    assert('First sync inserts 4 unique contacts', first.inserted, 4);
    assert('Record with no identity is skipped', first.skipped, 1);
    assert('Second sync inserts nothing', second.inserted, 0);
    assert('Row count unchanged after re-sync', countAfterSecond, countAfterFirst);
    assert('Changed contact is updated in place', third.updated, 1);
    assert('Row count unchanged after update sync', countAfterThird, countAfterFirst);
    assert('Updated value persisted', updatedRow.phone, '+19999999999');
  } finally {
    await db.query('DELETE FROM users WHERE id = ?', [userId]); // cascades to contacts
    await db.closeDatabase();
  }

  console.log(failures === 0 ? '\nAll checks passed.' : `\n${failures} check(s) failed.`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error('\nCheck failed to run:', err.message);
  process.exit(1);
});
